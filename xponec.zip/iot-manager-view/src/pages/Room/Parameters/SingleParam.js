import React from 'react';
import cls from './styles/deviceParams.module.css';

const SingleParam = ({ devid, paramid, name, value }) => {
	return <div cls={cls['param']}>Param in here</div>;
};

export default SingleParam;
